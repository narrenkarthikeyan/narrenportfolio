// ═══════════════════════════════════════════
//  STELLARA — Interactive Star Map
//  app.js — Canvas rendering + interaction
// ═══════════════════════════════════════════

const canvas = document.getElementById('skyCanvas');
const ctx = canvas.getContext('2d');
const tooltip = document.getElementById('tooltip');
const infoPanel = document.getElementById('infoPanel');

// ── Star Data ──────────────────────────────
const STARS = [
  // === ORION ===
  { id: 1, name: 'Betelgeuse', constellation: 'Orion', x: 0.22, y: 0.38, mag: 0.5, type: 'Red Supergiant', ra: '05h 55m 10s', dec: '+07° 24\'', dist: '700 ly', desc: 'One of the largest and most luminous stars visible to the naked eye, marking Orion\'s right shoulder.', myth: 'In Greek myth, Orion was a great hunter placed in the sky by Zeus. Betelgeuse marks his right shoulder, ever-ready to draw his club.' },
  { id: 2, name: 'Rigel', constellation: 'Orion', x: 0.26, y: 0.52, mag: 0.1, type: 'Blue Supergiant', ra: '05h 14m 32s', dec: '-08° 12\'', dist: '860 ly', desc: 'The brightest star in Orion, a blue-white supergiant 40,000× more luminous than our Sun.', myth: 'Rigel marks Orion\'s left foot — his kicking leg as he battles Taurus the Bull eternally across the winter sky.' },
  { id: 3, name: 'Bellatrix', constellation: 'Orion', x: 0.28, y: 0.37, mag: 1.6, type: 'Blue Giant', ra: '05h 25m 08s', dec: '+06° 21\'', dist: '250 ly', desc: 'The "Amazon Star" — Orion\'s left shoulder, a hot blue-white star about 6× the Sun\'s mass.', myth: 'Called the "Female Warrior" in Latin, Bellatrix was said to bring fortune to warriors born under her light.' },
  { id: 4, name: 'Alnilam', constellation: 'Orion', x: 0.24, y: 0.44, mag: 1.7, type: 'Blue Supergiant', ra: '05h 36m 13s', dec: '-01° 12\'', dist: '1340 ly', desc: 'The middle star of Orion\'s Belt — a brilliant blue supergiant nearly 375,000× the Sun\'s luminosity.', myth: 'The three belt stars were seen in many cultures as a bridge, a row of pearls, or three kings marching across the heavens.' },
  { id: 5, name: 'Alnitak', constellation: 'Orion', x: 0.22, y: 0.45, mag: 1.8, type: 'Blue Supergiant', ra: '05h 40m 46s', dec: '-01° 57\'', dist: '1260 ly', desc: 'The easternmost star of Orion\'s Belt, near the famous Horsehead Nebula.', myth: 'Ancient Egyptian temples were aligned to these three belt stars, reflecting the three pyramids of Giza.' },
  { id: 6, name: 'Mintaka', constellation: 'Orion', x: 0.26, y: 0.445, mag: 2.2, type: 'Blue Giant', ra: '05h 32m 00s', dec: '-00° 18\'', dist: '900 ly', desc: 'The westernmost belt star, nearly exactly on the celestial equator — making it rise due east globally.', myth: 'Mintaka guided ancient sailors as a perfect east-marker before magnetic compasses existed.' },
  { id: 7, name: 'Saiph', constellation: 'Orion', x: 0.21, y: 0.52, mag: 2.1, type: 'Blue Supergiant', ra: '05h 47m 45s', dec: '-09° 40\'', dist: '722 ly', desc: 'Marking Orion\'s right knee, Saiph is similar in size to Rigel yet appears dimmer.', myth: 'Saiph represents the hunter\'s mighty knee, planted firm as he draws his bow for the eternal hunt.' },

  // === URSA MAJOR ===
  { id: 8, name: 'Dubhe', constellation: 'Ursa Major', x: 0.48, y: 0.2, mag: 1.8, type: 'Orange Giant', ra: '11h 03m 44s', dec: '+61° 45\'', dist: '124 ly', desc: 'The brightest star in Ursa Major, forming the outer edge of the Big Dipper\'s bowl.', myth: 'In Greek myth, Zeus transformed Callisto into a bear and placed her in the sky. Dubhe is her broad back, forever circling the pole.' },
  { id: 9, name: 'Merak', constellation: 'Ursa Major', x: 0.5, y: 0.24, mag: 2.4, type: 'Blue-White Star', ra: '11h 01m 50s', dec: '+56° 22\'', dist: '79 ly', desc: 'Merak and Dubhe are the "pointer stars" — a line through them points to Polaris.', myth: 'Ancient navigators called these stars the "Guards of the Pole" — celestial sentinels who forever point north.' },
  { id: 10, name: 'Phecda', constellation: 'Ursa Major', x: 0.53, y: 0.27, mag: 2.4, type: 'Blue-White Star', ra: '11h 53m 50s', dec: '+53° 42\'', dist: '84 ly', desc: 'Part of the famous Ursa Major moving group — a cluster of stars born together, still traveling together.', myth: 'Phecda marks the Bear\'s haunch, its powerful hindquarters forever frozen mid-stride across the northern sky.' },
  { id: 11, name: 'Megrez', constellation: 'Ursa Major', x: 0.51, y: 0.22, mag: 3.3, type: 'White Star', ra: '12h 15m 26s', dec: '+57° 02\'', dist: '58 ly', desc: 'The faintest of the Big Dipper stars, joining the handle to the bowl.', myth: 'Called the "Root of the Bear\'s Tail," Megrez was thought to be the source of the bear\'s great strength.' },
  { id: 12, name: 'Alioth', constellation: 'Ursa Major', x: 0.5, y: 0.19, mag: 1.8, type: 'White Giant', ra: '12h 54m 02s', dec: '+55° 57\'', dist: '81 ly', desc: 'The brightest star in the handle of the Big Dipper, a spectroscopic binary with a magnetic field.', myth: 'In Chinese astronomy, Alioth and its handle companions were the jade balance-beam of heaven, weighing the fates of nations.' },
  { id: 13, name: 'Mizar', constellation: 'Ursa Major', x: 0.48, y: 0.17, mag: 2.0, type: 'White Giant', ra: '13h 23m 56s', dec: '+54° 56\'', dist: '78 ly', desc: 'One of the first double stars observed telescopically. The faint companion Alcor has been used as a vision test since antiquity.', myth: 'Arab astronomers called Mizar the "Groin of the Bear." Alcor, its faint companion, was the "Forgotten One" — a loyalty test for soldiers.' },
  { id: 14, name: 'Alkaid', constellation: 'Ursa Major', x: 0.46, y: 0.15, mag: 1.9, type: 'Blue-White Star', ra: '13h 47m 32s', dec: '+49° 19\'', dist: '101 ly', desc: 'The tip of the Big Dipper\'s handle — the end of the Great Bear\'s tail.', myth: 'Called "Destroyer of Nations" in old Arabic texts, Alkaid\'s heliacal rising was associated with battles and great upheavals.' },

  // === CASSIOPEIA ===
  { id: 15, name: 'Schedar', constellation: 'Cassiopeia', x: 0.7, y: 0.12, mag: 2.2, type: 'Orange Giant', ra: '00h 40m 30s', dec: '+56° 32\'', dist: '228 ly', desc: 'The brightest star in Cassiopeia, marking the queen\'s breast.', myth: 'Queen Cassiopeia of Ethiopia boasted that she was more beautiful than the Nereids. Poseidon was outraged and placed her in the sky chained to her throne, spinning round the pole forever.' },
  { id: 16, name: 'Caph', constellation: 'Cassiopeia', x: 0.68, y: 0.1, mag: 2.3, type: 'White Giant', ra: '00h 09m 11s', dec: '+59° 09\'', dist: '54 ly', desc: 'One of the stars used to find the prime meridian of the sky. Part of the W or M shape.', myth: 'In Persian star lore, Caph was one of the stars of the "Hand Stained with Henna" — part of a royal wedding preparation scene.' },
  { id: 17, name: 'Gamma Cas', constellation: 'Cassiopeia', x: 0.72, y: 0.11, mag: 2.2, type: 'Blue Subgiant', ra: '00h 56m 42s', dec: '+60° 43\'', dist: '613 ly', desc: 'A rapidly rotating Be star that ejects a circumstellar disk, causing irregular brightness changes.', myth: 'This volatile star was interpreted as Cassiopeia\'s restless vanity — sometimes dimming, sometimes burning bright like her pride.' },
  { id: 18, name: 'Ruchbah', constellation: 'Cassiopeia', x: 0.74, y: 0.13, mag: 2.7, type: 'White Subgiant', ra: '01h 25m 49s', dec: '+60° 14\'', dist: '99 ly', desc: 'An eclipsing binary star system where two stars regularly dim each other\'s light.', myth: 'Ruchbah means "knee" in Arabic — the queen\'s bent knee as she is tied to her revolving throne.' },
  { id: 19, name: 'Segin', constellation: 'Cassiopeia', x: 0.76, y: 0.14, mag: 3.4, type: 'Blue Giant', ra: '01h 54m 24s', dec: '+63° 40\'', dist: '443 ly', desc: 'The outermost star of the W shape, a hot blue giant much larger than our Sun.', myth: 'Segin is thought to mark the queen\'s raised hand, forever gesturing at her own reflection in the heavenly waters.' },

  // === SCORPIUS ===
  { id: 20, name: 'Antares', constellation: 'Scorpius', x: 0.62, y: 0.72, mag: 0.9, type: 'Red Supergiant', ra: '16h 29m 24s', dec: '-26° 26\'', dist: '550 ly', desc: 'A red supergiant so vast that if placed at the Sun, it would engulf Mercury, Venus, Earth and Mars.', myth: 'Antares means "rival of Mars" — its ruddy glow so similar to the red planet that ancient astronomers used the two to track each other across the sky.' },
  { id: 21, name: 'Shaula', constellation: 'Scorpius', x: 0.6, y: 0.78, mag: 1.6, type: 'Blue Subgiant', ra: '17h 33m 36s', dec: '-37° 06\'', dist: '700 ly', desc: 'Marks the tip of the scorpion\'s stinger — one of the brightest stars in Scorpius.', myth: 'Shaula is the scorpion\'s venomous stinger, forever poised to strike Orion, who flees across the western horizon as Scorpius rises.' },
  { id: 22, name: 'Graffias', constellation: 'Scorpius', x: 0.63, y: 0.66, mag: 2.6, type: 'Blue Giant', ra: '16h 05m 26s', dec: '-19° 48\'', dist: '530 ly', desc: 'A multiple star system forming the scorpion\'s head, also called Acrab.', myth: 'These claws are where the scorpion seized Orion, stinging him to death. The gods placed them both in the sky on opposite sides so they\'d never meet again.' },
  { id: 23, name: 'Dschubba', constellation: 'Scorpius', x: 0.64, y: 0.67, mag: 2.3, type: 'Blue Giant', ra: '16h 00m 20s', dec: '-22° 37\'', dist: '400 ly', desc: 'A rapidly rotating blue giant that belongs to the Scorpius-Centaurus association.', myth: 'Dschubba marks the scorpion\'s forehead — a proud creature whose victory over the great hunter Orion was celebrated across ancient cultures.' },

  // === LYRA ===
  { id: 24, name: 'Vega', constellation: 'Lyra', x: 0.55, y: 0.3, mag: 0.0, type: 'Blue-White Star', ra: '18h 36m 56s', dec: '+38° 47\'', dist: '25 ly', desc: 'The fifth brightest star in the night sky and the brightest in Lyra. About 2.1× the Sun\'s mass and 40× its luminosity.', myth: 'In Japanese legend, Vega is Orihime, a weaving princess separated from her love Altair by the Milky Way. They meet once a year during the Tanabata festival.' },
  { id: 25, name: 'Sheliak', constellation: 'Lyra', x: 0.56, y: 0.33, mag: 3.5, type: 'Eclipsing Binary', ra: '18h 50m 05s', dec: '+33° 22\'', dist: '960 ly', desc: 'A complex eclipsing binary system — two stars that periodically dim each other as they orbit.', myth: 'Sheliak and its companions form the strings of Apollo\'s lyre, each note of celestial music tied to a different star.' },
  { id: 26, name: 'Sulafat', constellation: 'Lyra', x: 0.57, y: 0.32, mag: 3.3, type: 'Blue Giant', ra: '18h 58m 57s', dec: '+32° 41\'', dist: '620 ly', desc: 'A shell star surrounded by a disk of ejected gas, giving it an unusual spectrum.', myth: 'Named for the tortoise shell that Hermes used to craft the first lyre — a divinely-inspired invention gifted to Apollo.' },

  // === CANIS MAJOR ===
  { id: 27, name: 'Sirius', constellation: 'Canis Major', x: 0.32, y: 0.55, mag: -1.5, type: 'Blue-White Star', ra: '06h 45m 09s', dec: '-16° 43\'', dist: '8.6 ly', desc: 'The brightest star in the entire night sky. A binary system 23× more luminous than the Sun.', myth: 'Ancient Egyptians called it Sopdet. Its heliacal rising marked the annual flooding of the Nile, making it the most important star in their calendar — a gift of life from the sky.' },
  { id: 28, name: 'Adhara', constellation: 'Canis Major', x: 0.33, y: 0.6, mag: 1.5, type: 'Blue Giant', ra: '06h 58m 38s', dec: '-28° 58\'', dist: '430 ly', desc: 'Would be the brightest star in the sky if it were as close to us as Sirius is.', myth: 'Adhara means "virgins" in Arabic — these stars were thought to be the handmaidens accompanying the great dog across the sky.' },
  { id: 29, name: 'Wezen', constellation: 'Canis Major', x: 0.31, y: 0.58, mag: 1.8, type: 'Yellow Supergiant', ra: '07h 08m 23s', dec: '-26° 23\'', dist: '1600 ly', desc: 'Despite appearing moderate, Wezen is intrinsically one of the most luminous stars known — 50,000× the Sun\'s output.', myth: 'Its name means "the weight" — ancient astronomers noted how this star seemed to pull the great dog earthward at the horizon, heavy with celestial purpose.' },
  { id: 30, name: 'Mirzam', constellation: 'Canis Major', x: 0.29, y: 0.53, mag: 2.0, type: 'Blue Giant', ra: '06h 22m 42s', dec: '-17° 57\'', dist: '500 ly', desc: 'A pulsating star that changes brightness due to pressure waves in its atmosphere.', myth: 'Called "The Announcer" — Mirzam rises just before Sirius, heralding the coming of the brightest star like a herald before a king.' },

  // === BACKGROUND STARS (unnamed, for ambience) ===
  ...Array.from({ length: 180 }, (_, i) => ({
    id: 100 + i,
    name: null,
    constellation: 'background',
    x: Math.random(),
    y: Math.random(),
    mag: 3.5 + Math.random() * 2.5,
    type: 'Background Star',
    ra: '', dec: '', dist: '',
    desc: '', myth: ''
  }))
];

// Constellation line connections [star_id, star_id]
const CONSTELLATION_LINES = {
  'Orion':      [[1,4],[4,5],[5,6],[6,3],[3,1],[4,3],[5,7],[6,2]],
  'Ursa Major': [[8,9],[9,10],[10,11],[11,12],[12,13],[13,14]],
  'Cassiopeia': [[16,15],[15,17],[17,18],[18,19]],
  'Scorpius':   [[22,23],[23,20],[20,21]],
  'Lyra':       [[24,25],[25,26],[26,24]],
  'Canis Major':[[27,30],[30,29],[29,28]],
};

// ── State ──────────────────────────────────
let showLines = true;
let showLabels = true;
let activeConstellation = 'all';
let hoveredStar = null;
let selectedStar = null;
let twinkleOffset = 0;

// ── Resize canvas ──────────────────────────
function resize() {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
}
window.addEventListener('resize', () => { resize(); draw(); });
resize();

// ── Draw nebula background ─────────────────
function drawBackground() {
  const w = canvas.width, h = canvas.height;

  // Deep sky gradient
  const bg = ctx.createRadialGradient(w * 0.5, h * 0.4, 0, w * 0.5, h * 0.5, Math.max(w, h) * 0.9);
  bg.addColorStop(0, '#05122a');
  bg.addColorStop(0.4, '#030c1e');
  bg.addColorStop(1, '#010610');
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, w, h);

  // Milky Way sweep
  ctx.save();
  const mw = ctx.createLinearGradient(0, 0, w, h);
  mw.addColorStop(0, 'rgba(60,80,160,0)');
  mw.addColorStop(0.3, 'rgba(40,60,130,0.07)');
  mw.addColorStop(0.5, 'rgba(80,100,180,0.12)');
  mw.addColorStop(0.7, 'rgba(50,70,150,0.07)');
  mw.addColorStop(1, 'rgba(20,40,100,0)');
  ctx.fillStyle = mw;
  ctx.fillRect(0, 0, w, h);

  // Nebula glow blobs
  const glows = [
    { x: 0.22, y: 0.44, r: 0.08, c: 'rgba(255,100,50,0.04)' },   // Orion nebula hint
    { x: 0.55, y: 0.30, r: 0.06, c: 'rgba(100,180,255,0.05)' },  // Vega region
    { x: 0.62, y: 0.72, r: 0.09, c: 'rgba(200,50,50,0.05)' },    // Antares region
    { x: 0.48, y: 0.20, r: 0.07, c: 'rgba(80,120,200,0.04)' },   // Ursa Major
  ];
  glows.forEach(g => {
    const rad = ctx.createRadialGradient(g.x * w, g.y * h, 0, g.x * w, g.y * h, g.r * Math.max(w, h));
    rad.addColorStop(0, g.c);
    rad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = rad;
    ctx.fillRect(0, 0, w, h);
  });
  ctx.restore();
}

// ── Draw constellation lines ───────────────
function drawLines() {
  if (!showLines) return;
  const w = canvas.width, h = canvas.height;
  const starById = {};
  STARS.forEach(s => { starById[s.id] = s; });

  Object.entries(CONSTELLATION_LINES).forEach(([name, pairs]) => {
    const isActive = activeConstellation === 'all' || activeConstellation === name;
    const alpha = isActive ? 0.35 : 0.06;

    pairs.forEach(([a, b]) => {
      const s1 = starById[a], s2 = starById[b];
      if (!s1 || !s2) return;
      ctx.beginPath();
      ctx.moveTo(s1.x * w, s1.y * h);
      ctx.lineTo(s2.x * w, s2.y * h);
      const grad = ctx.createLinearGradient(s1.x * w, s1.y * h, s2.x * w, s2.y * h);
      grad.addColorStop(0, `rgba(201,168,76,${alpha})`);
      grad.addColorStop(0.5, `rgba(180,220,255,${alpha * 0.8})`);
      grad.addColorStop(1, `rgba(201,168,76,${alpha})`);
      ctx.strokeStyle = grad;
      ctx.lineWidth = isActive ? 0.8 : 0.4;
      ctx.stroke();
    });
  });
}

// ── Draw a single star ─────────────────────
function drawStar(star) {
  const w = canvas.width, h = canvas.height;
  const sx = star.x * w, sy = star.y * h;

  const isBackground = star.constellation === 'background';
  const isActive = activeConstellation === 'all' || activeConstellation === star.constellation || isBackground;
  const isHovered = hoveredStar && hoveredStar.id === star.id;
  const isSelected = selectedStar && selectedStar.id === star.id;

  // Twinkle
  const twinkle = isBackground
    ? 0.7 + 0.3 * Math.sin(twinkleOffset * 0.5 + star.id * 1.7)
    : 0.85 + 0.15 * Math.sin(twinkleOffset + star.id * 2.3);

  // Size based on magnitude
  const maxMag = 4;
  const normMag = Math.max(0, (maxMag - star.mag) / (maxMag + 1.5));
  let baseRadius = isBackground ? 0.5 + normMag * 1.5 : 1.5 + normMag * 4;

  if (isHovered || isSelected) baseRadius *= 1.6;

  const r = baseRadius * twinkle;
  const alpha = isActive ? (isBackground ? 0.5 + normMag * 0.5 : 1) : 0.15;

  // Star color by type
  let color = '#d4dce8';
  if (star.type && star.type.includes('Red')) color = '#ffb08a';
  else if (star.type && star.type.includes('Orange')) color = '#ffd090';
  else if (star.type && star.type.includes('Yellow')) color = '#fff0a0';
  else if (star.type && star.type.includes('Blue')) color = '#c8e8ff';

  // Glow
  if (!isBackground && isActive) {
    const glowR = r * (isHovered ? 8 : 5);
    const glow = ctx.createRadialGradient(sx, sy, 0, sx, sy, glowR);
    const glowColor = star.type && star.type.includes('Red') ? '255,130,80' : '200,230,255';
    glow.addColorStop(0, `rgba(${glowColor},${0.12 * alpha * twinkle})`);
    glow.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = glow;
    ctx.beginPath();
    ctx.arc(sx, sy, glowR, 0, Math.PI * 2);
    ctx.fill();
  }

  // Star core
  const starGrad = ctx.createRadialGradient(sx - r * 0.2, sy - r * 0.2, 0, sx, sy, r);
  starGrad.addColorStop(0, `rgba(255,255,255,${alpha})`);
  starGrad.addColorStop(0.4, `rgba(${hexToRgb(color)},${alpha * 0.9})`);
  starGrad.addColorStop(1, `rgba(${hexToRgb(color)},0)`);

  ctx.beginPath();
  ctx.arc(sx, sy, r, 0, Math.PI * 2);
  ctx.fillStyle = starGrad;
  ctx.fill();

  // Selected ring
  if (isSelected) {
    ctx.beginPath();
    ctx.arc(sx, sy, r + 4, 0, Math.PI * 2);
    ctx.strokeStyle = `rgba(201,168,76,0.6)`;
    ctx.lineWidth = 1;
    ctx.stroke();
  }

  // Label
  if (showLabels && star.name && isActive && !isBackground) {
    ctx.fillStyle = `rgba(180, 200, 230, ${isActive ? 0.75 : 0.2})`;
    ctx.font = `${isHovered ? '700' : '400'} 10px 'Space Mono', monospace`;
    ctx.letterSpacing = '0.05em';
    ctx.fillText(star.name, sx + r + 5, sy - r - 3);
  }
}

// ── Main draw ──────────────────────────────
function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawBackground();
  drawLines();
  // Draw background stars first, then named stars
  STARS.filter(s => s.constellation === 'background').forEach(drawStar);
  STARS.filter(s => s.constellation !== 'background').forEach(drawStar);
}

// ── Animation loop ─────────────────────────
let lastTime = 0;
function animate(ts) {
  if (ts - lastTime > 50) { // ~20fps for twinkle
    twinkleOffset += 0.04;
    draw();
    lastTime = ts;
  }
  requestAnimationFrame(animate);
}
requestAnimationFrame(animate);

// ── Helpers ────────────────────────────────
function hexToRgb(hex) {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `${r},${g},${b}`;
}

function getStarAt(mx, my) {
  const w = canvas.width, h = canvas.height;
  let closest = null, minDist = 24;
  STARS.filter(s => s.name).forEach(s => {
    const sx = s.x * w, sy = s.y * h;
    const d = Math.hypot(mx - sx, my - sy);
    if (d < minDist) { minDist = d; closest = s; }
  });
  return closest;
}

// ── Mouse Events ───────────────────────────
canvas.addEventListener('mousemove', e => {
  const star = getStarAt(e.clientX, e.clientY);
  hoveredStar = star;
  canvas.style.cursor = star ? 'pointer' : 'crosshair';

  if (star) {
    tooltip.innerHTML = `
      <div class="tt-name">${star.name}</div>
      <div class="tt-const">${star.constellation}</div>
      <div class="tt-mag">Magnitude ${star.mag}</div>
    `;
    tooltip.classList.remove('hidden');
    const tx = Math.min(e.clientX + 14, window.innerWidth - 160);
    const ty = Math.max(e.clientY - 50, 10);
    tooltip.style.left = tx + 'px';
    tooltip.style.top = ty + 'px';
  } else {
    tooltip.classList.add('hidden');
  }
});

canvas.addEventListener('mouseleave', () => {
  hoveredStar = null;
  tooltip.classList.add('hidden');
});

canvas.addEventListener('click', e => {
  const star = getStarAt(e.clientX, e.clientY);
  if (star) openPanel(star);
});

// ── Info Panel ─────────────────────────────
function openPanel(star) {
  selectedStar = star;
  document.getElementById('panelConstellation').textContent = star.constellation.toUpperCase();
  document.getElementById('panelName').textContent = star.name;
  document.getElementById('panelType').textContent = star.type;
  document.getElementById('panelMag').textContent = `Mag ${star.mag}`;
  document.getElementById('panelDesc').textContent = star.desc;
  document.getElementById('panelRA').textContent = star.ra;
  document.getElementById('panelDec').textContent = star.dec;
  document.getElementById('panelDist').textContent = star.dist;
  document.getElementById('panelMyth').textContent = star.myth;

  infoPanel.classList.remove('hidden');
  setTimeout(() => infoPanel.classList.add('open'), 10);
}

document.getElementById('closePanel').addEventListener('click', () => {
  infoPanel.classList.remove('open');
  selectedStar = null;
  setTimeout(() => infoPanel.classList.add('hidden'), 420);
});

// ── Controls ───────────────────────────────
document.getElementById('toggleLines').addEventListener('click', function() {
  showLines = !showLines;
  this.textContent = showLines ? 'Hide Lines' : 'Show Lines';
});

document.getElementById('toggleLabels').addEventListener('click', function() {
  showLabels = !showLabels;
  this.textContent = showLabels ? 'Hide Labels' : 'Show Labels';
});

document.getElementById('btnRandom').addEventListener('click', () => {
  const named = STARS.filter(s => s.name && s.constellation !== 'background');
  const star = named[Math.floor(Math.random() * named.length)];
  openPanel(star);
  // Flash star
  hoveredStar = star;
  setTimeout(() => { hoveredStar = null; }, 1500);
});

// ── Constellation filter ───────────────────
document.querySelectorAll('.const-btn').forEach(btn => {
  btn.addEventListener('click', function() {
    document.querySelectorAll('.const-btn').forEach(b => b.classList.remove('active'));
    this.classList.add('active');
    activeConstellation = this.dataset.const;
    // Close panel if constellation changed
    if (selectedStar && activeConstellation !== 'all' && selectedStar.constellation !== activeConstellation) {
      infoPanel.classList.remove('open');
      selectedStar = null;
      setTimeout(() => infoPanel.classList.add('hidden'), 420);
    }
  });
});

// ── Touch support ──────────────────────────
canvas.addEventListener('touchend', e => {
  e.preventDefault();
  const t = e.changedTouches[0];
  const star = getStarAt(t.clientX, t.clientY);
  if (star) openPanel(star);
}, { passive: false });
