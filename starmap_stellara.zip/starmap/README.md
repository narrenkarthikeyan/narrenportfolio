# 🌟 Stellara — Interactive Star Map

> *Navigate the Ancient Sky*

A beautifully crafted interactive night sky explorer built with pure HTML, CSS, and JavaScript using the Canvas API. Explore constellations, click on stars, and uncover their mythology and astronomical data.

---

## 📁 Project Structure

```
starmap/
├── index.html    — App shell, layout, and semantic HTML
├── style.css     — Full dark-sky visual theme and responsive layout
├── app.js        — Canvas rendering engine, star data, and interactions
└── README.md     — This file
```

---

## 🚀 How to Run

1. Open the project folder in **VS Code**
2. Install the **Live Server** extension (by Ritwick Dey)
3. Right-click `index.html` → **"Open with Live Server"**
4. Your browser will open at `http://127.0.0.1:5500`

> **Alternatively**, simply double-click `index.html` to open it directly in any browser — no server required.

---

## ✨ Features

### 🌌 Interactive Night Sky Canvas
- A fully rendered night sky using the **HTML5 Canvas API**
- 180+ randomly distributed background stars for atmosphere
- 30 named stars across 6 constellations with accurate relative positions
- Smooth **twinkling animation** loop at ~20fps
- Radial gradient nebula glows and a Milky Way sweep effect

### ⭐ Named Stars (30 total)
| Constellation | Stars |
|---|---|
| **Orion** | Betelgeuse, Rigel, Bellatrix, Alnilam, Alnitak, Mintaka, Saiph |
| **Ursa Major** | Dubhe, Merak, Phecda, Megrez, Alioth, Mizar, Alkaid |
| **Cassiopeia** | Schedar, Caph, Gamma Cas, Ruchbah, Segin |
| **Scorpius** | Antares, Shaula, Graffias, Dschubba |
| **Lyra** | Vega, Sheliak, Sulafat |
| **Canis Major** | Sirius, Adhara, Wezen, Mirzam |

### 🔍 Star Interaction
- **Hover** over any named star to see a tooltip with its name, constellation, and magnitude
- **Click** any star to open a detailed side panel containing:
  - Star name and spectral type
  - Apparent magnitude
  - Description and physical properties
  - RA / Declination / Distance coordinates
  - Mythological story

### 🔭 Constellation Controls
- **Constellation filter bar** (bottom) — highlight individual constellations
- **Toggle Lines** — show/hide constellation stick-figure lines
- **Toggle Labels** — show/hide star name labels on canvas
- **Random Star** — opens a random star's info panel

---

## 🏗️ Technical Architecture

### `index.html`
Provides the page skeleton: a `<canvas>` element, a fixed header with controls, a slide-in info panel `<aside>`, a legend, and a constellation filter bar. Google Fonts are loaded for typography (Cormorant Garamond + Space Mono).

### `style.css`
Uses **CSS custom properties** (variables) for the entire color palette. Key design decisions:
- `position: fixed` overlay system for panel, header, legend
- CSS `transform` + `transition` for the slide-in panel animation
- `backdrop-filter: blur()` for frosted-glass effect on panels
- No external UI framework — all custom components

### `app.js`
The core engine, structured in layers:

1. **Star Data** — Array of 30 named star objects + 180 procedurally generated background stars. Each named star carries: name, constellation, normalized (x, y) coordinates, magnitude, spectral type, RA/Dec/distance, description, and mythology.

2. **Constellation Lines** — An adjacency object mapping constellation names to pairs of star IDs that should be connected.

3. **Rendering Pipeline** (called each frame):
   - `drawBackground()` — sky gradient + Milky Way linear gradient + radial nebula glows
   - `drawLines()` — iterates line pairs, draws gradient strokes
   - `drawStar()` — renders each star with:
     - Twinkle via `Math.sin(offset + id)`  
     - Size derived from apparent magnitude
     - Color from spectral type string
     - Radial gradient core + outer glow
     - Selected-star gold ring

4. **Hit Detection** — `getStarAt(mx, my)` searches for the closest named star within 24px of the cursor.

5. **Animation Loop** — `requestAnimationFrame` throttled to ~20fps for smooth but efficient twinkling.

---

## 🎨 Design Language

- **Color palette**: Deep navy sky (`#020818`) with gold (`#c9a84c`) and ice blue (`#4fc3f7`) accents
- **Typography**: Cormorant Garamond (editorial elegance) + Space Mono (technical data)
- **Motion**: Continuous star twinkling + panel slide-in on `cubic-bezier(0.16, 1, 0.3, 1)`
- **Layout**: Fixed-position overlays leave the canvas unobstructed

---

## 🌐 Browser Compatibility

Works in all modern browsers:
- Chrome 90+ ✅
- Firefox 88+ ✅
- Safari 14+ ✅
- Edge 90+ ✅

No build tools, no npm, no dependencies — pure vanilla web technologies.

---

## 📖 Astronomical Notes

Star positions on screen are artistically arranged for visual clarity and do not represent actual RA/Dec sky coordinates. Magnitude values, distances, spectral types, and mythological descriptions are accurate to published astronomical data.

---

*Built as part of Industrial Design & Research — Web Application Development Assignment*
